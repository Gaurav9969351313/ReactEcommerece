import React from 'react'

export default function Sidebar() {
    return (
        <div>
            this is sidebar
        </div>
    )
}
