import React from 'react'

export default function SideCart() {
    return (
        <div>
            this is side cart 
        </div>
    )
}
