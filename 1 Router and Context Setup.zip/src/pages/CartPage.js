import React from 'react'

export default function CartPage() {
    return (
        <div>
            This Is Cart Page
        </div>
    )
}
