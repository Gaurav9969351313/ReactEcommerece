import React from 'react'

export default function Default() {
    return (
        <div>
            This Is Default Page
        </div>
    )
}
