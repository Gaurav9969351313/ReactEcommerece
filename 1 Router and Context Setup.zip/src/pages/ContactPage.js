import React from 'react'

export default function ContactPage() {
    return (
        <div>
            This Is Contact Page 
        </div>
    )
}
