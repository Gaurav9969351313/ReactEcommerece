import React from 'react'

export default function AboutPage() {
    return (
        <div>
            This Is About Page
        </div>
    )
}
