import React from 'react'

export default function SingleProductPage() {
    return (
        <div>
            This is Single Product page 
        </div>
    )
}
