import React from 'react'

const ExpenseForm = ({ charge, amount, handleCharge, handleAmount, handleSubmit, edit }) => {
    return (
        <form className="form" onSubmit={handleSubmit}>
            <div>
                <label htmlFor="charge">Charge</label>
                <input type="text" id="charge" name="charge" value={charge} onChange={handleCharge} />
                <br />
                <label htmlFor="amount">Amount</label>
                <input type="text" id="amount" name="amount" value={amount} onChange={handleAmount} />
                <button id="submit" type="submit"  > { edit ? 'Edit' : 'Submit' } </button>
            </div>
        </form>
    )
}

export default ExpenseForm;