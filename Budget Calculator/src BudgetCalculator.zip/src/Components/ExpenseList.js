import React from 'react'
import Item from './ExpenseItem'

const ExpenseList = ({ expenses, handleEdit, handleDelete, clearItems }) => {
    return (
        <div>
            <ul className="list">
                {expenses.map((exp) => {
                        return <Item key={exp.id} 
                                    expense={exp} 
                                    handleDelete={handleDelete} 
                                    handleEdit={handleEdit} /> 
                    })
                }
            </ul>
            {expenses.length > 0 && <button className="btn" onClick={clearItems}>Clear Expenses</button>}
        </div>
    )
}

export default ExpenseList