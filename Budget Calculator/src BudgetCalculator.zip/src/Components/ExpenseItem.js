import React from 'react'
import { MdEdit, MdDelete } from 'react-icons/md';

const ExpenseItem = ({expense, handleEdit, handleDelete}) => {

    const { id, charge, amount } = expense;

    return (
        <li>
            <div className="info">
                <span className="expense"> {charge}</span>
                <span className="amount"> $ {amount} </span>
            </div>
            <div>
                <button className="editButton" onClick={() => handleEdit(id)} aria-label="edit Button"><MdEdit></MdEdit></button>
                <button className="deleteButton" onClick={() => handleDelete(id)} aria-label="delete Button"><MdDelete></MdDelete></button>
            </div>
        </li>
    )
}

export default ExpenseItem;