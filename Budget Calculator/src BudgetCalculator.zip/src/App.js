import React, { useState } from 'react';
import './App.css';
import uuid from 'uuid/v4'

import ExpenseList from './Components/ExpenseList'
import ExpenseForm from './Components/ExpenseForm'
import Alert from './Components/Alert'

// npm install react-icons uuid --save 

const initialExpenses = [
  { id: uuid(), charge: "pocket money", amount: 200 },
  { id: uuid(), charge: "housing loan", amount: 10000 },
  { id: uuid(), charge: "car payment", amount: 1212 },
]

console.log(initialExpenses);


function App() {

  // Getters And Setters
  const [expenses, setExpenses] = useState(initialExpenses);
  const [charge, setCharge] = useState('');
  const [amount, setAmount] = useState(0);
  const [alert, setAlert] = useState({ show: false });

  const [edit, setEdit] = useState(false);
  const [id, setId] = useState(0);

  const handleCharge = (e) => {
    console.log("Charge", e.target.value);
    setCharge(e.target.value);
  };

  const handleAmount = (e) => {
    console.log("Amount", e.target.value);
    setAmount(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(charge, amount);

    if (charge !== "" && amount > 0) {

      if (edit) {
        // #########################################################################################
        let temp = expenses.map(exp => { return exp.id === id ? { ...exp, charge,amount } : exp });

        setExpenses(temp);
        setEdit(false);
      } else {
        const singleExpense = { id: uuid(), charge: charge, amount: amount }
        setExpenses([...expenses, singleExpense]);
        handleAlert({ type: "sucess", text: "Item is being added" });
      }

      setCharge("");
      setAmount("");
    } else {
      handleAlert({ type: "danger", text: "Charge / Amount cant be empty" })
    }

  };

  const clearItems = () => {
    console.log("Clear Items Called")
    setExpenses([]);
  }

  const handleDelete = (id) => {
    console.log("Delete called ", id);
    let tempExpenses = expenses.filter(exp => exp.id !== id);
    setExpenses(tempExpenses);
    handleAlert({ type: 'danger', text: 'Item Deleted Sucessfully' });
  }

  const handleEdit = (id) => {
    console.log("Edit Called ", id);

    let expense = expenses.find(exp => exp.id === id);
    let { charge, amount } = expense;

    setCharge(charge);
    setAmount(amount);
    setId(id);
    setEdit(true);
  }

  const handleAlert = ({ type, text }) => {
    setAlert({ show: true, type, text });
    setTimeout(() => {
      setAlert({ show: false })
    }, 3000);
  }

  return (
    <div>
      {alert.show && <Alert type={alert.type} text={alert.text} />}
      <h1>Budget Calculator</h1>
      <div className="App">

        <ExpenseForm
          charge={charge}
          amount={amount}
          handleAmount={handleAmount}
          handleCharge={handleCharge}
          handleSubmit={handleSubmit}
          edit={edit}
        />

        <ExpenseList
          expenses={expenses}
          clearItems={clearItems}
          handleEdit={handleEdit}
          handleDelete={handleDelete} />
      </div>
      <h1>Total Spending: {expenses.reduce((acc, expense) => { return (acc += expense.amount); }, 0)}  </h1>
    </div>
  );
}

export default App;
